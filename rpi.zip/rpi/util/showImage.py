import cv2

def show(s, img):
    cv2.imshow(s, img)
    cv2.waitKey(1)